# API 注意事项

* 选用合适的Method
* 返回的数据结构要合理
* 标注必要的说明
> 请求数据，字段说明，一些枚举的说明
* [关于response的一些建议](https://confluence.synnex.com/display/GT/P1-API-Design-Principle)
