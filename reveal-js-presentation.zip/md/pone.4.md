## structure

![structure](./images/p1-ui-arch.png)