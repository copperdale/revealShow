## Workflow milestone

[Plan](https://confluence.synnex.com/display/GT/Cash+Posting+Matching+Plan)