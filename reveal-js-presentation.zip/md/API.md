# API 接口定义

<p>根据设计图确定所需要的API接口,包括url、method、parameter等相关细节</p>

[接口定义](http://10.17.2.184)