# 其他相关之Biz Component

* (biz组件)[https://us-dev-mycis.synnex.org/showcase]