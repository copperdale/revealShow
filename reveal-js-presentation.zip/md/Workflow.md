## Workflow

![structure](./images/workflow.png)