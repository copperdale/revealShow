# 其他相关之File upload

* 几种类型
* 适用场景
* 如何使用